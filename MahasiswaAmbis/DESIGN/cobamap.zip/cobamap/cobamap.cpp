// cobamap.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <allegro5\allegro5.h>
#include <allegro5\allegro_native_dialog.h>
#include <allegro5\allegro_image.h>

#define ScreenWidth 700
#define ScreenHeight 512

void CameraUpdate(float *cameraPosition, float x, float y, int widht, int height) 
{
	cameraPosition[0] = -(ScreenWidth / 2) + (x + widht /2);
	cameraPosition[1] = -(ScreenHeight / 2) + (y + height /2);
	 
	if (cameraPosition[0] < 0) {
		cameraPosition[0] = 0;
	} 
	if (cameraPosition[1] < 0) {
		cameraPosition[1] = 0;
	}
		
}

int main()
{
	ALLEGRO_DISPLAY *display;
	enum Direction { Down, Left, Right, Up };
	const float FPS = 60.0;
	const float frameFPS = 15.0;

	if (!al_init()) {
		al_show_native_message_box(NULL, "ERROR", NULL, "COULD NOT install allegro", NULL, NULL);
	}
	display = al_create_display(ScreenWidth, ScreenHeight);

	if (!display) {
		al_show_native_message_box(NULL, "ERROR", NULL, "COULD NOT SHOW DISPLAY", NULL, NULL);
	}

	al_set_window_position(display, 200, 200);
	bool done = false, draw = true, active = false;
	float x = 10, y = 372, moveSpeed = 3;
	int dir = Down, sourceX = 100, sourceY = 0;

	float cameraPosition[2] = { 0,0 };

	al_install_keyboard();
	al_init_image_addon();

	ALLEGRO_BITMAP *player = al_load_bitmap("Mahasiswa-fix.png");
	ALLEGRO_BITMAP *background = al_load_bitmap("map.png");

	ALLEGRO_KEYBOARD_STATE keyState;

	ALLEGRO_TRANSFORM camera;

	ALLEGRO_TIMER *timer = al_create_timer(1.0 / FPS);
	ALLEGRO_TIMER *frameTimer = al_create_timer(1.0 / frameFPS);

	ALLEGRO_EVENT_QUEUE *event_queue = al_create_event_queue();
	al_register_event_source(event_queue, al_get_timer_event_source(timer));
	al_register_event_source(event_queue, al_get_timer_event_source(frameTimer));
	al_register_event_source(event_queue, al_get_display_event_source(display));
	al_register_event_source(event_queue, al_get_keyboard_event_source());

	al_start_timer(timer);
	al_start_timer(frameTimer);
	int ceklompat = 0;

	while (!done) {
		ALLEGRO_EVENT events;
		al_wait_for_event(event_queue, &events);
		al_get_keyboard_state(&keyState);
		if (events.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {
			done = true;
		}
		else if (events.type == ALLEGRO_EVENT_TIMER) {
			if (y < 372) {
				y += moveSpeed;
			}
			if (ceklompat == 1) {
				x += moveSpeed;
				ceklompat = 0;
			}
			if (events.timer.source == timer) {
				active = true;
				/*if (al_key_down(&keyState, ALLEGRO_KEY_DOWN)) {
					y += moveSpeed;
					//dir = Down;
				} else*/ if (al_key_down(&keyState, ALLEGRO_KEY_UP)) {
					y -= 10;
					ceklompat = 1;
					//dir = Up;
				} else if (al_key_down(&keyState, ALLEGRO_KEY_RIGHT)) {
					x += moveSpeed;
					dir = Right;
				} else if (al_key_down(&keyState, ALLEGRO_KEY_LEFT)) {
					x -= moveSpeed;
					dir = Left;
				} 
				
				else {
					active = false;
				}

				CameraUpdate(cameraPosition, x, 0, 50, 94);

				al_identity_transform(&camera);
				al_translate_transform(&camera, -cameraPosition[0], -cameraPosition[1]);
				al_use_transform(&camera);
			}

			else if (events.timer.source == frameTimer) {
				if (active) {
					sourceX += 54;
				}
				else {
					sourceX = 50;
				}
				if (sourceX>=al_get_bitmap_width(player)) {
					sourceX = 0;
				}
				sourceY = dir;
			}
			draw = true;
		}

		if (draw) {
			ALLEGRO_BITMAP *subBitmap = al_create_sub_bitmap(player, sourceX, 0, 50, 94);
			al_draw_bitmap(background, 0, 0, NULL);
			al_draw_bitmap(subBitmap, x, y, NULL);

			al_flip_display();
			al_clear_to_color(al_map_rgb(0, 0, 0));
			al_destroy_bitmap(subBitmap);
		}
	}

	al_destroy_display(display);
	al_destroy_timer(timer);
	al_destroy_timer(frameTimer);
	al_destroy_bitmap(player);
	al_destroy_bitmap(background);
	al_destroy_event_queue(event_queue);
    return 0;
}

